<?php 

/**
 * Sidebar
 * 
 * @package Remix
 * @author Codevz
 * @link http://codevz.com
 */

global $codevz;

$cpt = $codevz->get_post_type();
$p = $codevz->sidebar_p();
$s = $codevz->sidebar_s();
$l = $codevz->option( $cpt . 'layout', $codevz->option( 'layout', 'sidebar-right' ) );
$sticky_sidebar = $codevz->option( 'sticky_sidebar' ) ? ' sticky_sidebar' : '';

if ( is_page() || is_single() && $cpt !== 'bbpress_' ) {
	$m = $codevz->meta();
	if ( isset( $m['layout'] ) && $m['layout'] !== 'inherit' ) {
		$l = $m['layout'];
	} 
}

if ( $l === 'sidebar-right' ) {
	echo '<aside class="grid_4 omega' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $p );
	echo '</div></aside>';
} else if ( $l === 'sidebar-left' ) {
	echo '<aside class="grid_4 alpha' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $p );
	echo '</div></aside>';
} else if ( $l === 'both-sidebar' ) {
	echo '<aside class="grid_3 righter omega' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $s );
	echo '</div></aside>';
} else if ( $l === 'both-sidebar-right' ) {
	echo '<aside class="grid_3' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $s );
	echo '</div></aside><aside class="grid_3 omega' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $p );
	echo '</div></aside>';
} else if ( $l === 'both-sidebar-left' ) {
	echo '<aside class="grid_3 alpha' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $p );
	echo '</div></aside><aside class="grid_3' . $sticky_sidebar . '"><div>';
	$codevz->dynamic_sidebar( $s );
	echo '</div></aside>';
}
