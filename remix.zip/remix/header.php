<!DOCTYPE html>
<head <?php language_attributes(); ?>>
	<meta charset="<?php bloginfo( 'charset' );?>" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<?php 
	global $codevz;

	/* Body attrs */
	$attrs = ' data-ajax="'.admin_url( 'admin-ajax.php' ).'" data-theme="'.CD_URI.'"';
	$body_class = array(
		( (int) $codevz->option( 'scrollbar' ) === 2 ) ? 'scroll' : '',
		$codevz->option( 'isGlass' ) ? 'isGlass' : ''
	);
?>

<body <?php body_class( implode( ' ', $body_class ) ); echo $attrs; ?>>

	<?php if ( $codevz->option( 'pageloader' ) ) {
		$pbg = $codevz->option( 'pageloader_bg', array() );
		echo '<style>.pageloader {
				background-image: url(' . isset( $pbg['image'] ) ? $pbg['image'] : '' . ') !important;
				background-color: ' . isset( $pbg['color'] ) ? $pbg['color'] : 'inherit' . ' !important;
				background-repeat: ' . isset( $pbg['repeat'] ) ? $pbg['repeat'] : 'repeat' . ' !important;
				background-position: ' . isset( $pbg['position'] ) ? $pbg['position'] : 'left top' . ' !important;
				background-attachment: ' . isset( $pbg['attachment'] ) ? $pbg['attachment'] : 'scroll' . ' !important;
		}</style>';
		echo '
			<div class="pageloader" data-time="' . $codevz->option( 'pageloader_time' ) . '">
				<img src="' . $codevz->option( 'pageloader_img' ) . '" width="auto" height="auto" />
			</div>
		';
	} ?>

	<div id="layout" class="<?php echo $codevz->option( 'full_boxed', 'full' ); ?>">

		<?php 
			/* Options */
			$cpt 	= $codevz->get_post_type();
			$shead 	= $GLOBALS['sfoot'] = 1;
			$header = $codevz->option( 'header', '1' );
			$type 	= $codevz->option( $cpt . 'cover', '1' );

			$cpt 	= ( $type === '1' ) ? '' : $cpt;
			$type 	= empty( $cpt ) ? $codevz->option( 'cover', '1' ) : $type;
			$img 	= $codevz->option( $cpt . 'img' );
			$master = $codevz->option( $cpt . 'master' );
			$rev 	= $codevz->option( $cpt . 'rev' );
			$pos 	= $codevz->option( $cpt . 'cover_position', 0 );
			$show_alphabet = 0;
			
			/* Reset cpt */
			$cpt = $codevz->get_post_type();
			$cpt = ( $cpt === 'page_' || $cpt === 'post_' ) ? '' : $cpt;
			$br = $codevz->option( $cpt . 'breadcrumbs' );

			/* Singular */
			if ( is_page() || is_single() && $cpt !== 'bbpress_' ) {
				$meta = $codevz->meta();
				if ( isset( $meta['cover'] ) && $meta['cover'] !== '1' ) {
					$type 	= $meta['cover'];
					$img 	= $meta['img'];
					$master = $meta['master'];
					$rev 	= $meta['rev'];
					$pos 	= $meta['cover_position'];
				}

				$hmeta = empty( $meta['hiding_elms'] ) ? array() : (array) $meta['hiding_elms'];
				$hmeta = array_flip( $hmeta );
				$shead = !isset( $hmeta['header'] );
				$br = isset( $hmeta['breadcrumbs'] ) ? 0 : $br;
				$GLOBALS['sfoot'] = !isset( $hmeta['footer'] );
				$show_alphabet = isset( $meta['show_alphabet'] ) ? $meta['show_alphabet'] : 0;
			}

			/* Header */
			$codevz->hook( 'before_header' );
			ob_start(); ?>
				<header id="header">
					<div class="row clr">
					<?php if ( $codevz->option( 'social' ) || $codevz->option( 'header_custom_text' ) || $codevz->option( 'shop_cart' ) || $codevz->option( 'search' ) ) { ?>
						<div class="little-head">
							<?php 
								/* Login */
								$codevz->login_html();

								/* Shopping cart */
								if ( function_exists('is_woocommerce') && $codevz->option('woocommerce_cart') ) {
									echo '<div class="cz_cart_p">';
									echo '<a class="shop_icon" href="' . esc_url( wc_get_cart_url() ) . '"><i class="fa fa-shopping-basket"></i></a><div class="cz_cart"></div>';
									echo '</div>';
								}

								/* Social icons */
								$codevz->social( $codevz->option( 'social' ), array_filter( array(
									$codevz->option( 'social_position' ),
									$codevz->option( 'social_colored' ) ? 'colored' : '',
									$codevz->option( 'social_circular' ) ? 'circular' : ''
								) ) );

								/* Custom HTML */
								echo $codevz->option( 'header_custom_text' ) ? '<div class="text_head">'. $codevz->option( 'header_custom_text' ) . '</div>' : '';

								/* Search */
								echo $codevz->option( 'search_placeholder' ) ? $codevz->search_form() : '';
							?>
						</div><!--/little-head -->
						<div class="clr"></div>
					<?php } ?> 

						<div class="headdown clr<?php echo $codevz->option( 'sticky' ) ? ' is_sticky' : ''; echo $codevz->option( 'sticky_smart' ) ? '' : ' smart_off'; ?>">
							<?php 
								echo $codevz->option( 'sticky' ) ? '<div class="row clr">' : '';
								$codevz->logo();
							?>
							<nav id="mobile">
								<?php $codevz->menu( 'primary', ( $codevz->option( 'fullscreen_menu' ) ? 'sf-menu fullscreen_menu' : 'sf-menu' ) ); ?>
							</nav>
							<?php echo $codevz->option( 'sticky' ) ? '</div>' : ''; ?>
						</div><!--/headdown -->

					</div><!--/row -->
				</header>
			<?php 
			$head_out = ob_get_clean();
			echo $shead ? $head_out : '';
			$codevz->hook( 'after_header' );

			/* Cover */
			$type = (int) $type;
			if ( $type === 3  && $img ) {
				echo '<div class="page_cover under_header'. ( $pos ? ' after_header' : '' ) . '"><img src="'.$img.'" alt="Header" width="auto" height="auto" /></div>';
			} elseif ( $type === 4 && class_exists( 'RevSliderFront' ) ) {
				echo '<div class="page_cover '. ( $pos ? '' : ' overlay_header' ) . '">';
				echo putRevSlider( $rev );
				echo '</div>';
			} elseif ( $type === 5 && class_exists( 'Master_Slider' ) ) {
				echo '<div class="page_cover '. ( $pos ? '' : ' overlay_header' ) . '">';
				echo masterslider( $master );
				echo '</div>';
			}

			/* Start content */
			echo '<div id="page-content">';

				echo '<div class="page-content">';

				/* Breadcrumbs */
				if ( $br && ! is_front_page() ) { 
					echo '<div class="row clr mb">';
						echo '<div class="breadcrumbIn" itemprop="breadcrumb">';
							$codevz->breadcrumbs();
						echo '</div>';
					echo '</div>';
				} 

				/* Alphabet list */
				$alphabet = array_flip( (array) $codevz->option( $cpt . 'alphabet' ) );
				if ( isset( $alphabet[ $codevz->get_page_type() ] ) || $show_alphabet ) {
					$codevz->alphabet_list();
				}

				echo '<div class="row clr">';
