<?php

/**
 * @package Remix
 * @author Codevz
 * @link http://Codevz.com
 */

if ( !class_exists( 'CodevzInstagram' ) ) {

	add_action( 'widgets_init', function() {
		register_widget('CodevzInstagram');
	});

	class CodevzInstagram extends WP_Widget {

		function __construct() {
			parent::__construct(
				false, 
				esc_html__( 'CD - Instagram', 'remix' ), 
				array( 'classname' => 'cd_instagram' )
			);
		}

		public function widget( $args, $instance ) {
			extract( $args );
			$title = apply_filters( 'widget_title', $instance['title'] );
			$out = $before_widget."\n";
			$out .= $title ? $before_title . $title . $after_title : '';
			$count = $instance['count'] ? $instance['count'] : 9;
			$username = esc_html( $instance['username'] );

			$query = $this->scrape_instagram( $username );

			if ( ! is_array( $query ) ) {
				echo $before_widget . $title;
				delete_transient( 'codevz-instagram-' . $username );
				echo $after_widget;
				return;
			}

			ob_start();
			$out .= '<ul class="in_insta clr">';

			$i = 0;
			foreach ( (array) $query as $q ) {
				$link = empty( $q['link'] ) ? 'https://instagram.com/' . $username : $q['link'];
				$desc = empty( $q['description'] ) ? $username : strip_tags( $q['description'] );
				$img = empty( $q['thumbnail'] ) ? '#' : $q['thumbnail'];

				$out .= '<li><a class="cdEffect noborder" href="' . $link . '" target="_blank" title="' . $desc . '"><img src="' . $img . '" width="auto" height="auto" /><i class="fa fa-instagram"></i></a></li>';
				$i++;
				if ( $i == $count ) {
					break;
				}
			}


			$out .= '</ul>';
			$out .= ob_get_clean();
			$out .= $after_widget."\n";
			echo $out;
		}
		
		public function update( $new, $old ) {
			$instance = $old;
			$instance['title'] = strip_tags( $new['title'] );
			$instance['username'] = strip_tags( $new['username'] );
			$instance['count'] = strip_tags( $new['count'] );

			return $instance;
		}

		public function form( $instance ) {
			$defaults = array(
				'title' 	=> 'Instagram',
				'count' 	=> '9',
				'username' 	=> 'Codevz'
			);
			$instance = wp_parse_args( (array) $instance, $defaults );

			echo csf_add_field( array(
				'id'    => $this->get_field_name('title'),
				'name'  => $this->get_field_name('title'),
				'type'  => 'text',
				'title' => esc_html__('Title', 'remix')
			), esc_attr( $instance['title'] ) );

			echo csf_add_field( array(
				'id'    => $this->get_field_name('username'),
				'name'  => $this->get_field_name('username'),
				'type'  => 'text',
				'title' => esc_html__('Username', 'remix')
			), esc_attr( $instance['username'] ) );

			echo csf_add_field( array(
				'id'    => $this->get_field_name('count'),
				'name'  => $this->get_field_name('count'),
				'type'  => 'number',
				'title' => esc_html__('Count', 'remix')
			), esc_attr( $instance['count'] ) );

		}

		/**
		 *
		 * Scrape instagram data via wp_remote_get
		 * 
		 * @var username or hashtag, updating transient time
		 * @return array
		 * 
		 */
		function scrape_instagram( $username, $tt = 72 ) {

			$username = strtolower( $username );
			$is_tag = ( strpos( $username, '#' ) !== false ) ? 1 : 0;
			$username = str_replace( array( '@', '#' ), '', $username );
			$instagram = get_transient( 'codevz-instagram-' . sanitize_title_with_dashes( $username ) );

			if ( ! $instagram ) {
				$remote = wp_remote_get( 'https://instagram.com/' . ( $is_tag ? 'explore/tags/' : '' ) . trim( $username ) );

				if ( is_wp_error( $remote ) ) {
					return esc_html__( 'Unable to communicate with Instagram.', 'remix' );
				} else if ( 200 != wp_remote_retrieve_response_code( $remote ) ) {
					return esc_html__( 'Instagram did not return a 200.', 'remix' );
				}

				$shards = explode( 'window._sharedData = ', $remote['body'] );
				$insta_json = explode( ';</script>', $shards[1] );
				$insta_array = json_decode( $insta_json[0], TRUE );

				if ( ! $insta_array ) {
					return esc_html__( 'Instagram has returned invalid data.', 'remix' );
				} else if ( $is_tag && isset( $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'] ) ) {
					$images = $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'];
				} else if ( isset( $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] ) ) {
					$images = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'];
				} else {
					return esc_html__( 'Instagram has returned invalid data.', 'remix' );
				}

				if ( ! is_array( $images ) ) {
					return esc_html__( 'Instagram has returned invalid data.', 'remix' );
				}

				$instagram = array();

				foreach ( $images as $image ) {
					$id = isset( $image['node']['shortcode'] ) ? $image['node']['shortcode'] : 'xxx';
					$instagram[] = array(
						'description'   => empty( $image['node']['edge_media_to_caption']['edges'][0]['node']['text'] ) ? '' : $image['node']['edge_media_to_caption']['edges'][0]['node']['text'],
						'link'		  	=> trailingslashit( '//instagram.com/p/' . $id ),
						'comments'	  	=> empty( $image['node']['edge_liked_by']['edge_media_to_comment'] ) ? '' : $image['node']['edge_liked_by']['edge_media_to_comment'],
						'likes'		 	=> empty( $image['node']['edge_liked_by']['count'] ) ? '' : $image['node']['edge_liked_by']['count'],
						'thumbnail'	 	=> 'https://instagram.com/p/' . $id . '/media/?size=t',
						'large'			=> 'https://instagram.com/p/' . $id . '/media/?size=m',
						'original'		=> 'https://instagram.com/p/' . $id . '/media/?size=l',
					);
				}

				// do not set an empty transient - should help catch private or empty accounts
				if ( ! empty( $instagram ) ) {
					set_transient( 'codevz-instagram-' . sanitize_title_with_dashes( $username ), $instagram, 3600 * $tt );
				}
			}

			if ( ! empty( $instagram ) ) {
				return $instagram;
			} else {
				return esc_html__( 'Instagram did not return any data.', 'remix' );
			}

		}

	}

}
