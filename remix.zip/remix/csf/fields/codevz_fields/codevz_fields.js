;(function ( $, window, document, undefined ) {
  'use strict';

  $(document).ready( function() {

    var mute_plugins = $('.plugins').find('[data-slug="slider-revolution"], [data-slug="wpbakery-visual-composer"], [data-slug="master-slider-pro"], [data-slug="essential-grid"]');
    if ( mute_plugins.length ) {
      mute_plugins.each(function() {
        $( this ).next('.plugin-update-tr').hide();
        $( this ).next('.plugin-update-tr').next('.plugin-update-tr').hide();
      });
    }

    // Date time
    $(".datetimepicker").each(function(){
      $( this ).appendDtpicker({
        "dateFormat": "YYYY/MM/DD h:m",
        "minuteInterval": 15,
        "autodateOnStart": false
      });
    });

    // Slider
    $.fn.csf_slider = function() {
      return this.each(function() {

        $( this ).html('<div></div>');

        var dis    = $( this ),
            input  = dis.prev('input'),
            slider = $( '> div', dis ),
            data   = dis.data( 'options' );

        slider.slider({
          range: 'min',
          value: parseInt( input.val() || 0 ),
          step: data.step,
          min: parseInt( data.min ),
          max: parseInt( data.max ),
          slide: function( e, o ) {
            input.val( ( o.value || 0 ) + data.unit ).trigger( 'change' );
          }
        });

        input.keyup( function() {
          slider.slider({ value: parseInt( input.val() || 0 ) });
        });

      });
    };

    // Autocomplete
    $.fn.csf_autocomplete = function() {
      return this.each(function() {
        var ac    = $( this ),
            time  = false,
            query = ac.data('query');

        // Keyup input and send ajax
        $( '> input', ac ).on( 'keyup', function() {
            clearTimeout( time );
            var val     = $( this ).val(),
                results = $( '.ajax_items', ac );

            if ( val.length < 2 ) {
                results.slideUp();
                $( '.fa-codevz', ac ).removeClass( 'fa-spinner fa-pulse' );
                return;
            }
            $( '.fa-codevz', ac ).addClass( 'fa-spinner fa-pulse' );

            time = setTimeout( function() {
              $.ajax({
                  type: "GET",
                  url: ajaxurl,
                  data: $.extend( query, {s: val} ),
                  success: function( data ) {
                      results.html( data ).slideDown();
                      $( '.fa-codevz', ac ).removeClass( 'fa-spinner fa-pulse' );
                  },
                  error: function( xhr, status, error ) {
                      results.html( '<div>' + error + '</div>' ).slideDown();
                      $( '.fa-codevz', ac ).removeClass( 'fa-spinner fa-pulse' );
                      console.log( xhr, status, error );
                  }
              });
            }, 1000 );
        });

        // Choose item from ajax results
        $( '.ajax_items', ac ).on('click', 'div', function() {
            var id    = $( this ).data('id'),
                title = $( this ).html();

            if ( $( '.multiple', ac ).length ) {
              var target = 'append';
              var name = query.elm_name + '[]';
            } else {
              var target = 'html';
              var name = query.elm_name;
            }

            if ( $( this ).closest('.csf-cloneable-content').length && $( this ).closest('csf-field-track') ) {
              name = $( this ).closest('.csf-cloneable-content').find('select').attr('name');
              var new_name_id = $( '> input', ac ).data('sub-depend-id');
              name = name.replace( 'track_type', new_name_id );
              name = name.replace( 'type', new_name_id );
            }

            $( '> input', ac ).val('');
            $( '.ajax_items' ).slideUp();
            if ( $( '#' + id, ac ).length ) {
              return;
            }

            $( '.selected_items', ac )[ target ]( '<div id="' + id + '"><input type="text" name="' + name + '" value="' + id + '" data-customize-setting-link="' + name + '" /><span> ' + title + '<i class="fa fa-remove"></i></span></div>' );
            $( ':input', ac ).trigger( 'change' );
            
            if ( wp.customize != undefined && wp.customize ) {
              wp.customize.control( name ).setting.set( id );
            }

            //ac.csf_customizer_refresh();
        });

        // Remove selected items
        $( '.selected_items', ac ).on('click', '.fa-remove', function() {
            $( this ).parent().parent().detach();
        });

        $( '.cs-autocomplete, .ajax_items' ).on( 'click', function(e) {
            e.stopPropagation();
        });
        
        $( 'body' ).on( 'click', function(e) {
            $( '.ajax_items' ).slideUp();
        });

      });
    };

    $(document).on('csf-reload-script', function( event, $this ) {
      $this.find('.csf-slider').not('.csf-no-script').csf_slider();
      $this.find('.cs-autocomplete').not('.csf-no-script').csf_autocomplete();
    });

    $( '#menu-management .item-edit' ).on('click', function(e) {
      $( this ).closest('li').csf_reload_script();
    });

    $('ul.menu').on('change', 'li', function() {
      if ( $( this ).hasClass('pending') ) {
        $( this ).csf_reload_script();
      }
    });
    
  });

})( jQuery, window, document );