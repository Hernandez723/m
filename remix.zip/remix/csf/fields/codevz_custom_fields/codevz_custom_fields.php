<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

if( ! class_exists( 'CSF_Field_fixed' ) ) {
  class CSF_Field_fixed extends CSF_Fields {
    public function __construct( $field, $value = '', $unique = '', $where = '' ) {
      parent::__construct( $field, $value, $unique, $where );
    }
    public function output(){}
  }
}