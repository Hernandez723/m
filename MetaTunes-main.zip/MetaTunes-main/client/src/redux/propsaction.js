export const NAVCOLOR = "NAVCOLOR";
export const LOGINCOLOR = "LOGINCOLOR";
export const ARTISTID = "ARTISTID";
export const USEREXIT = "USEREXIT";
export const CANCEL = "CANCEL";
