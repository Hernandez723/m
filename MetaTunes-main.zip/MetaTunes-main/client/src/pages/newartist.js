import React from 'react'

const Newartist = () => {
  return (
    <div className="Newartist">
        
    </div>
  )
}

export default Newartist