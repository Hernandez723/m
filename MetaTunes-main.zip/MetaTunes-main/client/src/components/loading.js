import React from 'react'
import '../scss/loading.scss';
const Loading = () => {
  return (
     <div className="loader">
        <div className="header">
            <div className="image">
            </div>
            <div className="text">
                <div className="text1"></div>
                <div className="text2">
                <div className="text3"></div>
                <div className="text3" id='tee'></div>
                <div className="text3"></div>
                <div className="text3" id='teee'></div>
                <div className="text3" id='te' ></div>
                <div className="text3"></div>
                </div>

            </div>
        </div>
        <div className="songwala"></div>
        <div className="bigtext"></div>
        <div className="bigtext"></div>
        <div className="bigtext"></div>
     </div>
  )
}

export default Loading